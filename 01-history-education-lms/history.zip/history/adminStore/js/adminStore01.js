// 관리자 로그인
async function checkLogin() {
    try {
        const response = await fetch("/api/check-login", {
            credentials: "include"
        });
        const data = await response.json();

        const userDiv = document.getElementById("user");
        const usernameLink = document.getElementById("userName-link");
        // id 수정됨

        if (data.isLoggedIn) {
            // 관리자인지 확인
            if (data.role === "admin") {
                usernameLink.textContent = data.username + "관리자";
                usernameLink.href = "/admin/dashboard.html";
                // 관리자 페이지
            } else {
                usernameLink.textContent = data.username;
                usernameLink.href = "/mypage/mypage.html";
                // 일반 유저 페이지
            }
            userDiv.style.display = "block";
        } else {
            userDiv.style.display = "none";
        }
    } catch (err) {
        console.error("로그인 체크 에러:", err);
    }
}

// 페이지 로드 시 로그인 체크
window.onload = () => {
    checkLogin();     // 로그인 체크
    renderProducts(1);  // 첫 페이지 게시글 로드
};

// 한 페이지당 5개
const pageSize = 5;
let currentPage = 1;

// 상품
// 상품 더미 데이터 (DB 연동 전 테스트용)
let products = [
    { id: 1, name: "투썸플레이스 쿠폰", price: 50, image: "coffee.png" },
    { id: 2, name: "문화상품권 100", price: 100, image: "culture100.png" },
    { id: 3, name: "문화상품권 300", price: 300, image: "culture300.png" },
    { id: 4, name: "문화상품권 500", price: 500, image: "culture500.png" },
    { id: 5, name: "스타벅스 쿠폰", price: 50, image: "starbucks.png" },
    { id: 6, name: "이디야 쿠폰", price: 50, image: "ediya.png" },
    { id: 7, name: "CGV 영화관람권", price: 500, image: "cgv.png" }
];

const productBody = document.getElementById("product-body");

// 상품 목록 렌더링
function renderProducts(page = 1) {
    currentPage = page;
    productBody.innerHTML = "";

    const start = (page - 1) * pageSize;
    const end = start + pageSize;
    const pageProducts = products.slice(start, end);

    pageProducts.forEach(product => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
      <td>${product.id}</td>
      <td>${product.name}</td>
      <td>${product.price} 점</td>
      <td>
        <button class="editBtn" data-id="${product.id}">수정</button>
        <button class="deleteBtn" data-id="${product.id}">삭제</button>
      </td>
    `;
        productBody.appendChild(tr);
    });

    // 남은 빈 행 채우기
    const emptyRows = pageSize - pageProducts.length;
    for (let i = 0; i < emptyRows; i++) {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>&nbsp;</td>
          <td></td>
          <td></td>
          <td></td>
        `;
        productBody.appendChild(tr);
    }

    // 이벤트 다시 연결
    document.querySelectorAll(".editBtn").forEach(btn => {
        btn.addEventListener("click", () => openEditModal(btn.dataset.id));
    });

    document.querySelectorAll(".deleteBtn").forEach(btn => {
        btn.addEventListener("click", () => deleteProduct(btn.dataset.id));
    });

    // 페이징 다시 렌더링
    renderPagination(products.length, currentPage);
}

// 상품 모달 관련
const editModal = document.getElementById("editProductModal");
const closeBtn = editModal.querySelector(".closeBtn");
const editForm = document.getElementById("editProductForm");

let editingProductId = null;

// 수정 모달 열기
function openEditModal(id) {
    const product = products.find(p => p.id == id);
    if (!product) return;

    editingProductId = id;
    document.getElementById("editProductName").value = product.name;
    document.getElementById("editProductPrice").value = product.price;

    editModal.classList.add("show");
}

// 수정 모달 닫기
function closeEditModal() {
    editModal.classList.remove("show");
}

// 상품 수정 완료
editForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("editProductName").value;
    const price = document.getElementById("editProductPrice").value;

    const product = products.find(p => p.id == editingProductId);
    if (product) {
        product.name = name;
        product.price = price;

        // 이미지 파일 수정 처리 (테스트용: 파일 이름만 반영)
        const imageFile = document.getElementById("editProductImage").files[0];
        if (imageFile) {
            product.image = imageFile.name;
        }
    }

    renderProducts();
    closeEditModal();
});

// 상품 삭제 기능
function deleteProduct(id) {
    products = products.filter(p => p.id != id);
    renderProducts();
}

// 닫기 버튼
closeBtn.addEventListener("click", closeEditModal);

// 처음 렌더링
// renderProducts();

// 페이징 버튼
function renderPagination(totalItems, currentPage) {
    const paginationDiv = document.getElementById("pagination");
    paginationDiv.innerHTML = "";

    const totalPages = Math.ceil(totalItems / pageSize);

    // ◀ 이전 버튼
    const prevBtn = document.createElement("button");
    prevBtn.textContent = "◀";
    prevBtn.disabled = currentPage === 1;
    prevBtn.addEventListener("click", () => renderProducts(currentPage - 1));
    paginationDiv.appendChild(prevBtn);

    // 페이지 번호 버튼
    for (let i = 1; i <= totalPages; i++) {
        const btn = document.createElement("button");
        btn.textContent = i;
        if (i === currentPage) btn.classList.add("active");
        btn.addEventListener("click", () => renderProducts(i));
        paginationDiv.appendChild(btn);
    }

    // ▶ 다음 버튼
    const nextBtn = document.createElement("button");
    nextBtn.textContent = "▶";
    nextBtn.disabled = currentPage === totalPages;
    nextBtn.addEventListener("click", () => renderProducts(currentPage + 1));
    paginationDiv.appendChild(nextBtn);
}
